-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 01, 2026 at 04:10 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portal_sekolah_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `alumni`
--

CREATE TABLE `alumni` (
  `id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `graduation_year` year(4) NOT NULL,
  `major` varchar(100) NOT NULL,
  `current_activity` varchar(150) NOT NULL,
  `university_or_company` varchar(150) DEFAULT NULL,
  `testimonial` text DEFAULT NULL,
  `photo_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `alumni`
--

INSERT INTO `alumni` (`id`, `full_name`, `graduation_year`, `major`, `current_activity`, `university_or_company`, `testimonial`, `photo_url`, `created_at`) VALUES
(1, 'Rizky Ramadhan, S.Kom.', '2023', 'MIPA', 'Software Engineer', 'PT Tokopedia Indonesia', 'Pendidikan dasar sains di SMAN 1 Nusantara sangat membantu fondasi logika pemrograman saya di kuliah.', 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=300&q=80', '2026-10-01 06:12:56'),
(2, 'Sarah Aulia Putri, S.E.', '2022', 'IPS', 'Business Analyst', 'Bank Central Asia (BCA)', 'Suasana belajar yang suportif melatih saya untuk berpikir kritis dalam dunia korporat.', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=300&q=80', '2026-10-01 06:12:56'),
(3, 'Ahmad Fauzan Hakim', '2024', 'MIPA', 'Mahasiswa Kedokteran', 'Universitas Indonesia (UI)', 'Berkat bimbingan guru-guru hebat, saya berhasil lolos jalur SNBP di Fakultas Kedokteran impian saya.', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', '2026-10-01 06:12:56'),
(4, 'Dinda Lestari, S.S.', '2021', 'Bahasa & Budaya', 'Content Creator & Translator', 'Freelance / Global Media', 'Ekosistem literasi sekolah membimbing saya mengeksplorasi bahasa asing hingga berkarier secara global.', 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=300&q=80', '2026-10-01 06:12:56');

-- --------------------------------------------------------

--
-- Table structure for table `contact_aspirations`
--

CREATE TABLE `contact_aspirations` (
  `id` int(11) NOT NULL,
  `sender_name` varchar(150) NOT NULL,
  `sender_role` varchar(100) NOT NULL,
  `message` text NOT NULL,
  `status` enum('Belum Dibalas','Terselesaikan') DEFAULT 'Belum Dibalas',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `contact_aspirations`
--

INSERT INTO `contact_aspirations` (`id`, `sender_name`, `sender_role`, `message`, `status`, `created_at`) VALUES
(1, 'Bambang Hariyadi', 'Wali', 'Mohon izin bertanya mengenai jadwal tes kesehatan mandiri untuk...', 'Belum Dibalas', '2026-09-30 14:39:49'),
(2, 'Yayasan Alumni SMAN 1', 'Alumni', 'Pengajuan sponsorship untuk beasiswa siswa berprestasi tingkat...', 'Terselesaikan', '2026-09-30 14:39:49');

-- --------------------------------------------------------

--
-- Table structure for table `facilities`
--

CREATE TABLE `facilities` (
  `id` int(11) NOT NULL,
  `title` varchar(150) NOT NULL,
  `description` text NOT NULL,
  `image_url` varchar(500) NOT NULL,
  `category` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facilities`
--

INSERT INTO `facilities` (`id`, `title`, `description`, `image_url`, `category`) VALUES
(1, 'Perpustakaan Digital Cendekia', 'Dilengkapi bilik diskusi multimedia, akses jurnal internasional bereputasi, serta sistem peminjaman mandiri berbasis RFID.', 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=600&q=80', 'Literasi Digital'),
(2, 'Laboratorium STEM & Riset Terpadu', 'Mewadahi riset mikrobiologi, kimia terapan, hingga workshop fabrikasi robotika dengan panduan teknis tersertifikasi.', 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=600&q=80', 'Sains & Komputasi'),
(3, 'Gedung Olahraga & Seni Pertunjukan', 'Gedung serbaguna berstandar federasi olahraga dengan tata suara akustik profesional untuk kegiatan pentas seni dan turnamen siswa.', 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=600&q=80', 'Multipurpose Court');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `category` enum('Prestasi Siswa','Akademik','Pengumuman','Kegiatan Sekolah') NOT NULL,
  `author_name` varchar(100) NOT NULL,
  `thumbnail_url` varchar(500) NOT NULL,
  `content` text NOT NULL,
  `status` enum('Published','Draft') DEFAULT 'Published',
  `views` int(11) DEFAULT 0,
  `published_at` datetime NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `slug`, `category`, `author_name`, `thumbnail_url`, `content`, `status`, `views`, `published_at`, `created_at`) VALUES
(1, 'Tim Olimpiade Fisika SMAN 1 Nusantara Raih 2 Emas di Tingkat Nasional 2025', 'berita/prestasi-medali-emas-olimpiade-sains-2025', 'Prestasi Siswa', 'Dr. Ratna Sari', 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=600&q=80', 'Dedikasi dan pelatihan intensif selama 6 bulan di bawah bimbingan guru pembina berhasil membawa pulang medali kehormatan tertinggi.', 'Published', 1420, '2025-10-12 09:40:00', '2026-09-30 14:39:49'),
(2, 'Sosialisasi Penerapan Asesmen Terintegrasi dalam Kurikulum Sains Mandiri', 'berita/asesmen-digital-portofolio-2025', 'Akademik', 'Anisa W., S.Pd', 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=600&q=80', 'Menyongsong integrasi modul menyajikan alur rincian alur jadwal simulasi CBT dan evaluasi portofolio siswa.', 'Published', 845, '2025-10-08 14:15:00', '2026-09-30 14:39:49'),
(3, 'Pekan Olahraga dan Seni Nusantara (PORSENI) 2025', 'berita/porseni-antarkelas-nusantara-2025', 'Kegiatan Sekolah', 'Rian H., M.I.Kom', 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=600&q=80', 'Memupuk sportivitas, solidaritas dan bakat non-akademik siswa melalui ajang kompetisi antar kelas.', 'Published', 612, '2025-10-01 10:00:00', '2026-09-30 14:39:49'),
(4, 'testing', 'testing', 'Prestasi Siswa', 'kendis', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYOywi2BMbJvWkE5pkvQ9pzlHLDn6TL9sdZjmdleWUP38DYmFHuTrwQyfU7wEov2yg9J00NpIAe84NvDQ8SWYDO87HpYZq1T3pEjf06Uw-RA&s=10', 'testing doang', 'Published', 0, '2026-09-30 17:49:00', '2026-09-30 15:50:37');

-- --------------------------------------------------------

--
-- Table structure for table `ppdb_registrations`
--

CREATE TABLE `ppdb_registrations` (
  `id` int(11) NOT NULL,
  `registration_number` varchar(50) NOT NULL,
  `nisn` varchar(20) NOT NULL,
  `nik` varchar(20) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `birth_place` varchar(100) NOT NULL,
  `birth_date` date NOT NULL,
  `gender` enum('Laki-laki','Perempuan') NOT NULL,
  `religion` varchar(50) NOT NULL,
  `origin_school` varchar(150) NOT NULL,
  `admission_path` enum('Prestasi Akademik','Zonasi','Afirmasi','Mutasi') NOT NULL,
  `target_major` varchar(100) NOT NULL,
  `report_avg_score` decimal(5,2) DEFAULT 0.00,
  `zone_distance` decimal(4,2) DEFAULT 0.00,
  `status_selection` enum('Pending','Diterima','Ditolak') DEFAULT 'Pending',
  `document_status` enum('Lengkap','Belum Lengkap') DEFAULT 'Belum Lengkap',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ppdb_registrations`
--

INSERT INTO `ppdb_registrations` (`id`, `registration_number`, `nisn`, `nik`, `full_name`, `birth_place`, `birth_date`, `gender`, `religion`, `origin_school`, `admission_path`, `target_major`, `report_avg_score`, `zone_distance`, `status_selection`, `document_status`, `created_at`) VALUES
(1, 'PPDB-2025-0142', '0078192831', '3174092408070002', 'Rizky Pratama', 'Jakarta', '2008-05-14', 'Laki-laki', 'Islam', 'SMP Negeri 1 Nusantara', 'Prestasi Akademik', 'MIPA 1 (Sains)', 89.40, 1.40, 'Diterima', 'Lengkap', '2026-09-30 14:39:49'),
(2, 'PPDB-2025-0143', '0079201145', '3174092001050001', 'Annisa Rahmawati', 'Bandung', '2008-08-22', 'Perempuan', 'Islam', 'SMP Labschool', 'Zonasi', 'MIPA 2 (Sains)', 94.12, 0.50, 'Diterima', 'Lengkap', '2026-09-30 14:39:49'),
(3, 'PPDB-2025-0144', '0081293309', '3174091512080004', 'Dimas Aditya', 'Tangerang', '2008-01-10', 'Laki-laki', 'Islam', 'SMP Al-Azhar', 'Afirmasi', 'IPS 1', 82.10, 3.20, 'Pending', 'Belum Lengkap', '2026-09-30 14:39:49'),
(4, 'PPDB-2026-2613', '11111111', '8764345689', 'kendis', 'tng', '2005-05-05', 'Laki-laki', 'Islam', 'tangerang', 'Prestasi Akademik', 'MIPA 1 (Sains)', 90.00, 1.00, 'Diterima', 'Belum Lengkap', '2026-09-30 15:49:10');

-- --------------------------------------------------------

--
-- Table structure for table `school_statistics`
--

CREATE TABLE `school_statistics` (
  `id` int(11) NOT NULL,
  `label` varchar(100) NOT NULL,
  `value_number` varchar(50) NOT NULL,
  `sub_label` varchar(150) NOT NULL,
  `icon_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `school_statistics`
--

INSERT INTO `school_statistics` (`id`, `label`, `value_number`, `sub_label`, `icon_name`) VALUES
(1, 'Siswa Aktif', '1250+', 'Terbagi dalam 36 rombongan belajar unggulan', 'users'),
(2, 'Guru Tersertifikasi', '78', 'Pendidik profesional bersertifikat pendidik nasional', 'user-check'),
(3, 'Kelas & Laboratorium', '36', 'Dilengkapi interactive smart board dan lab terakreditasi', 'home'),
(4, 'Penghargaan Prestasi', '142+', 'Tingkat provinsi, nasional, dan olimpiade internasional', 'award');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `id` int(11) NOT NULL,
  `nip` varchar(50) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `category_group` varchar(100) NOT NULL,
  `position` varchar(100) NOT NULL,
  `education_degree` varchar(50) NOT NULL,
  `certification_status` varchar(100) NOT NULL,
  `photo_url` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`id`, `nip`, `full_name`, `category_group`, `position`, `education_degree`, `certification_status`, `photo_url`, `created_at`) VALUES
(1, '19800412 200604 1 005', 'Hendra Kurniawan, M.Pd.', 'MIPA • FISIKA TERAPAN', 'Guru Mata Pelajaran / Pembina', 'S2 Fisika Material - ITB', 'Sertifikasi Guru Ahli Madya', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80', '2026-09-30 14:39:49'),
(2, '19850624 200902 2 008', 'Nurul Hidayah, M.Pd.', 'MIPA • MATEMATIKA PEMINATAN', 'Guru Mata Pelajaran', 'S2 Pendidikan Matematika - UM', 'Master Trainer Geogebra ID', 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80', '2026-09-30 14:39:49'),
(3, '19740104 200801 1 012', 'Dr. Ratna Sari, M.Pd.', 'PIMPINAN SEKOLAH', 'Kepala Sekolah SMAN 1 Nusantara', 'S3 Manajemen Pendidikan (UNJ)', 'Pendidik Profesional Bersertifikat Pendidik Nasional', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80', '2026-09-30 14:39:49');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `role` varchar(50) DEFAULT 'Admin',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `role`, `created_at`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70', 'Administrator Utama', 'Admin', '2026-09-30 16:06:15');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alumni`
--
ALTER TABLE `alumni`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_aspirations`
--
ALTER TABLE `contact_aspirations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facilities`
--
ALTER TABLE `facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `ppdb_registrations`
--
ALTER TABLE `ppdb_registrations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `registration_number` (`registration_number`),
  ADD UNIQUE KEY `nisn` (`nisn`);

--
-- Indexes for table `school_statistics`
--
ALTER TABLE `school_statistics`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `teachers`
--
ALTER TABLE `teachers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `nip` (`nip`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alumni`
--
ALTER TABLE `alumni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact_aspirations`
--
ALTER TABLE `contact_aspirations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `facilities`
--
ALTER TABLE `facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ppdb_registrations`
--
ALTER TABLE `ppdb_registrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `school_statistics`
--
ALTER TABLE `school_statistics`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `teachers`
--
ALTER TABLE `teachers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
